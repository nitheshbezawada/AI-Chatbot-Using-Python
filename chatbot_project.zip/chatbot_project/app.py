from flask import Flask, request, jsonify, render_template, send_from_directory
from langchain_ollama import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate
from PyPDF2 import PdfReader
import os

# Flask app setup
app = Flask(__name__)

# Global variables for chatbot state
history = ""
document_content = ""

# Chatbot setup
template_with_doc = """
Answer the question below based on the provided document content.

Here is the conversation history: {history}
Document Content: {document_content}
Question: {question}

Answer:
"""

template_general = """
Answer the question below.

Here is the conversation history: {history}
Question: {question}

Answer:
"""

model = OllamaLLM(model="llama3.2")
prompt_with_doc = ChatPromptTemplate.from_template(template_with_doc)
prompt_general = ChatPromptTemplate.from_template(template_general)

def extract_text_from_pdf(file_path):
    """Extract text from a PDF file."""
    try:
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        return text.strip()
    except Exception as e:
        return f"Error reading PDF: {e}"

@app.route("/")
def index():
    """Render the main chat interface."""
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload_document():
    """Handle document upload."""
    global document_content
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file uploaded!"}), 400
    if not file.filename.lower().endswith(".pdf"):
        return jsonify({"error": "Unsupported file format. Only PDF files are allowed!"}), 400

    try:
        # Save the uploaded file temporarily
        file_path = os.path.join("uploads", file.filename)
        os.makedirs("uploads", exist_ok=True)
        file.save(file_path)

        # Extract text from the PDF
        document_content = extract_text_from_pdf(file_path)
        os.remove(file_path)  # Remove the file after processing

        if "Error" in document_content:
            return jsonify({"error": document_content}), 500

        return jsonify({"message": "Document uploaded successfully!"})
    except Exception as e:
        return jsonify({"error": f"Failed to process the file: {e}"}), 500

@app.route("/ask", methods=["POST"])
def ask():
    """Handle user queries."""
    global history, document_content
    user_message = request.json.get("message", "")
    if not user_message.strip():
        return jsonify({"error": "Message is empty!"}), 400

    # Handle the "exit" command
    if user_message.lower() == "exit":
        document_content = ""  # Clear the uploaded document content
        history = ""  # Clear the conversation history
        return jsonify({"message": "Chatbot reset to a fresh stage. Document content cleared."})

    try:
        # Use the appropriate prompt
        if document_content:
            response = (prompt_with_doc | model).invoke({
                "history": history,
                "document_content": document_content,
                "question": user_message
            })
        else:
            response = (prompt_general | model).invoke({
                "history": history,
                "question": user_message
            })

        # Update history
        history += f"\nUser: {user_message}\nAI: {response}"
        return jsonify({"response": response})
    except Exception as e:
        return jsonify({"error": f"An error occurred: {e}"}), 500

if __name__ == "__main__":
    app.run(debug=True)
